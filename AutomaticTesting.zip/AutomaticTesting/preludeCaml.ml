exception E of int

let prInt k = (print_int k; print_newline(); k);;
