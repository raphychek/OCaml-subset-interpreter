let g x y = x * y in
    prInt (g 2)
