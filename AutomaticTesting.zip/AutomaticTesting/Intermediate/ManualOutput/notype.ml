let a = 32 in if a<64 then prInt(a*52) else a 17


