let g x = x*52 in prInt (g 32)
	       
