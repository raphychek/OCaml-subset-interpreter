let rec fact n = if n<2 then 1 else let f = fact in n * (f (n-1));;
prInt (fact 3)