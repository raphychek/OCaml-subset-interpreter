let f = fun x -> fun y -> x*y;;
prInt (f 3 5);; 