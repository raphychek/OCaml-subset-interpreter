try
	let a = 2 in if a=2 then raise (E a) else prInt 1 
with E 2 -> prInt 2