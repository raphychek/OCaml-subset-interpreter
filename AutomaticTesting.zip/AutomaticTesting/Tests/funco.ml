let f = fun (x,y) -> x*y in
prInt (f (3,4))