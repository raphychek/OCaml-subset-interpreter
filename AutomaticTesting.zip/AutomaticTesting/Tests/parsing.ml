let a x y = x+y in
let b = 2 in
let d z = z in
let c = 2 in
let e = 1 in 

prInt (a b c - d e)