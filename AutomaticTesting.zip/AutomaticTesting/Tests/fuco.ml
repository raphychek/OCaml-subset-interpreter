let c = fun x -> x,2;;
prInt (fst (c 1));;