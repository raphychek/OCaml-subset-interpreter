let y = 3 in 
try
  let y = 2 in ()
with
| _ -> let _ = prInt y in ();
let _ = prInt y in ();;