try (try raise (E (-2)) with E 1 -> 1) with E -2 -> prInt 0;;
