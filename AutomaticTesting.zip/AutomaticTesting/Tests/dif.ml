let a = 2;;
let b = 2;;
if not(a <> b) then prInt 1 else prInt 0;;