let f = fun x y z -> x*y+z in
prInt (f 2 3 4);; 