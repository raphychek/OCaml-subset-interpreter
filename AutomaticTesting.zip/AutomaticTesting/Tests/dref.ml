let a = ref 2;;
let b = ref 8;;
prInt (!a + !b)