let a = ref (fun x-> x*x)
let b = ref (!a 2);;
prInt (!b);;