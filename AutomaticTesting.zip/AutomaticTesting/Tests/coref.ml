let c = 1,2;;
let a = ref c;;
a := 3,4;
prInt (snd !a)