let c = if 1=2 then 1,2 else 3,4 in
let b = 2, if 1=1 then 5 else 6 in
prInt (fst c);
prInt (snd b)