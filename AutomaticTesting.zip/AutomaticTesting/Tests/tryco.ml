let c = try raise (E 2) with | E x -> x,7 in
prInt (fst c)