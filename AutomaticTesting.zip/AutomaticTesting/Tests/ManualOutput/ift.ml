let a = 1
let b = 2
let c = 3
let _ = if a<b then if c>a then prInt 1 else prInt 2 else 0;;