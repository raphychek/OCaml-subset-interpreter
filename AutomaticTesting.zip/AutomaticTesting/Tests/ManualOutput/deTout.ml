let a = 3
let f x = fun y -> x*y
let rec g c x y = if y=0 then c else g (c+x) x (y-1);;
if not(f 4 5 <> g 0 5 4) then prInt (a+-2) else 0;;