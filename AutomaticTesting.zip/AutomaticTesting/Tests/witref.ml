let a = ref 1;;

try 
	a := 5;
	raise (E !a) 
with E 5 -> prInt !a