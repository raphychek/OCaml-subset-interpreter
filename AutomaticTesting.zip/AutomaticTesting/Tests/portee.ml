let x = 5 in
let z = x in
let n = 3 in
prInt (let n = -1-2 in z*n) + n