let a = ref 2 in
prInt (!a);;