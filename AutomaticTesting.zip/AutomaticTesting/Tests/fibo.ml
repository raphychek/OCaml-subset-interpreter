let rec fib n =
  if n < 2 then n
  else (fib (n - 2)) + (fib (n - 1))
let _ = prInt (fib 0)
let _ = prInt (fib 1)
let _ = prInt (fib 2)
let _ = prInt (fib 3)
let _ = prInt (fib 4)
let _ = prInt (fib 5);;
prInt (fib 12)