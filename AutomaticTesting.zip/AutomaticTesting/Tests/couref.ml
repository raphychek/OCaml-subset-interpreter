let a = ref 2 in
let _ = (a := 1),(a := 2) in
prInt !a;;