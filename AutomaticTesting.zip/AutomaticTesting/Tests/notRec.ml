let rec f = 2;;
let rec h  = let rec g x = if x=0 then 1 else x*(g (x-1)) in g;; 
let _ = prInt f in prInt (h 4);;