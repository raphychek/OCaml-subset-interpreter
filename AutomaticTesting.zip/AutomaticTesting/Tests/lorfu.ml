let phi = ref (fun x-> x);;
let f x = if x = 0 then 1 else (1+ (!phi (x-1)));;
phi := f;
prInt (f 41);;