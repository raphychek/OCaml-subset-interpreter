let a = 1;;
let _ = a