let pile = 0, ref () in
let push x s =
	let (l, e) = s in
	(l+1, ref(x,e))
in
let s = push 2 pile in
let (a, sn) = s in
prInt a;;