let _ = try (let _ = raise (E 2)+ raise (E 3) in 1) with E x -> x;;
let _ = try (let _ = raise (E 2)+ 3 in 1) with E x -> x;;
let _ = try (let _ = 2+ raise (E 3) in 1) with E x -> x;;
let _ = try (let _ = (raise (E 2), raise (E 3)) in 1) with E x -> x;;
