let a,b = 1,(2,3) in
prInt (fst b);;