let x x = if x=0 then let x=1 in x else let rec f x = if x=1 then 1 else x*(f (x-1)) in f x;;
let x = prInt (x 5) in prInt x;;