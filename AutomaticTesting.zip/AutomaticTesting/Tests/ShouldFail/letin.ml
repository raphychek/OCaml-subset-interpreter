let a = 1 in
let b = 2
let c = 3;;