let _r = 2
let _ = prInt _r;;
let __ = 1;;
let f = _ 2;;
prInt __;;