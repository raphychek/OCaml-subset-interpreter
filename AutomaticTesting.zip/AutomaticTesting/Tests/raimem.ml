let y = 3;;
try
  let y = 1 in raise (E 2)
with
| E x -> prInt x;
prInt y