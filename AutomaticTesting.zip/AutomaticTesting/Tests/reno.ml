let rec fact n = if n<2 then 1 else n * (fact (n-1));;
let f = fact in prInt (f 5);;