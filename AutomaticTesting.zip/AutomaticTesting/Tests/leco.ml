let c = let x = 1 in x,2;;
prInt (fst c);;