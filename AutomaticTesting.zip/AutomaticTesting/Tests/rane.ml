try 
	let x = -3 in
	raise (E (x+1))
with E -2 -> prInt 1;;