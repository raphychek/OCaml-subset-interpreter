let a = ref (E 1) in 
try
  raise !a
with
E x -> (let _ = prInt x in ());;