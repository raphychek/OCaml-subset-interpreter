let rec f x = if x=0 then 1 else 
let rec g x = if x=1 then 1 else x*(g (x-1)) in g x;;
prInt (f 5);;