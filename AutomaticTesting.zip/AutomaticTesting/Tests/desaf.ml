let c = (1,2) in
let x,y = c in
prInt x;;