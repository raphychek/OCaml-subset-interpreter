let (f:int->int->int) = fun x y-> x+y in
prInt (f 3 4);;