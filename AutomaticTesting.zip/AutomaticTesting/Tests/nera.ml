try
	raise (E (-2))
with 
	| E x -> prInt x;;