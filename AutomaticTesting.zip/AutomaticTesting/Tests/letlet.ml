let a = 3 in
let f x = let b = 2 in x*b in
prInt (f a)