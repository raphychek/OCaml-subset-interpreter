try
	let _ = raise (E 2) in 1
with E x -> prInt x 