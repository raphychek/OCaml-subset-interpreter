let zero = 0 ;;
let rec u x = 
	if x > 0 then
	  let zero = 1 in
	  u (x-1)
	else
	  zero
;;

prInt (u 2)