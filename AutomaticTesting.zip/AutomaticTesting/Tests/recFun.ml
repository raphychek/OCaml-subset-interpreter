let rec f = (fun x -> if x=0 then 1 else x*(f (x-1)));;
let rec g = fun x -> if x=0 then 1 else x*(g (x-1));;
let _ = prInt (f 5) in prInt (g 5);;