prInt (if 0 < 1 then 1 else 0);;
