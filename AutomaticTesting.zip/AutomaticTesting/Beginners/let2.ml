let x = 32 in
prInt ((let x = 51 in x+1)*x)

	   
	   
