let x = (let y = 1 in y) in
    prInt y
