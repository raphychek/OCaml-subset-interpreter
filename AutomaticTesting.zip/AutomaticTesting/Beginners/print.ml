prInt (32*52);;


