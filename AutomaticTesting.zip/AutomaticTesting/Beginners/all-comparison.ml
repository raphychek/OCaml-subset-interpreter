let u = 4 / 4
let a = if 0 < u then 1 else 0
let b = if 0 <= u then 1 else 0
let c = if u > 0 then 1 else 0
let d = if u >= 0 then 1 else 0
let e = if u <> 0 then 1 else 0
let f = if u = 1 then 1 else 0
let r = a * b * c * d * e * f;;
prInt r
